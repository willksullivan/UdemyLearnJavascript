// log a message
console.log("This is log message");

// output an error
console.error("This is an error");

// add an info
console.info("Add an info to console");

// output warning
console.warn("This is your first warning");
