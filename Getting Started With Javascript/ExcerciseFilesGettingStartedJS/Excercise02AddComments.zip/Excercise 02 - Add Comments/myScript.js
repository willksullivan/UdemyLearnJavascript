// This is single line comment
alert("I just wrote single line comment!");

/*
This is mulit line comment
And it will be ignored 
by JavaScript Engine
*/

//document.write("I just wrote multi line comment");